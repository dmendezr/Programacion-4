﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppAdivinanzas
{
    public class Pregunta
    {

        #region Atributos
            
            public int atrIdPregunta { get; set; }
            public string atrPregunta { get; set; }
            public List<Respuesta> atrListaRespuesta { get; set; }

        #endregion

        #region Constructor

        public Pregunta() { }

        #endregion

        #region Metodos
            

        #endregion


    }
}
