﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AppAdivinanzas
{

    //Esta clase representa la respuesta a la pregunta
    public class Respuesta
    {

        #region "Atributos"
            public int atrIdRespuesta {get; set; }
            public string atrRespuesta { get; set; }
            public bool atrCorrecta { get; set; }
        #endregion

        #region Constructor
            public Respuesta() { }
        #endregion


        #region "Metodos"
        #endregion




        //

    }
}
